package commands;

import commands.templer.Command;
import command_control.gen.ParamBox;

public class ExecuteScriptCommand extends Command {

    private String fileName;

    public ExecuteScriptCommand(ParamBox paramBox){
        if (paramBox.size() == 1){
            fileName = (String) paramBox.toUnpack().get().getVal();
        }
    }

    @Override
    public ParamBox execute() {
//        mbTerminal.executeScript(fileName);
        return null;
    }
}
