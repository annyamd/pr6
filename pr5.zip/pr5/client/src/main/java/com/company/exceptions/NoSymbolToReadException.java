package com.company.exceptions;

public class NoSymbolToReadException extends Exception{
}
