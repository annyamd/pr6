package commands;

import command_control.gen.Messenger;
import command_control.gen.ParamBox;
import commands.templer.Command;
import command_control.gen.Param;
import command_control.gen.ParamType;

public class HelpCommand extends Command {
    @Override
    public ParamBox execute() {
        return new ParamBox(1).add(new Param(ParamType.STRING, Param.NO_NAME_FIELD,
                Messenger.getCommandsDescription()));
    }
}
