package id;

public interface Identifiable {
    long getId();
    void setId(long id);
}
