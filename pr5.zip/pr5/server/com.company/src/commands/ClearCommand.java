package commands;

import command_control.gen.ParamBox;
import db.MusicBandHashSet;
import commands.templer.Command;

public class ClearCommand extends Command {

    public ClearCommand(MusicBandHashSet receiver){
        super(receiver);
    }

    @Override
    public ParamBox execute() {
        receiver.getData().clear();
        return null;
    }
}
