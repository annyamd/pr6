package exceptions;

public class ServerClientException extends Exception{
}
