package commands;

import command_control.gen.ParamBox;
import db.MusicBandHashSet;
import commands.templer.Command;

public class RemoveByIdCommand extends Command {
    private long id;

    public RemoveByIdCommand(MusicBandHashSet receiverHashSet, ParamBox paramBox){
        super(receiverHashSet, paramBox);

        if (paramBox.size() == 1){
            id = (long) paramBox.toUnpack().get().getVal();
        }
    }

    @Override
    public ParamBox execute() {
        receiver.removeById(id);
        return null;
    }
}