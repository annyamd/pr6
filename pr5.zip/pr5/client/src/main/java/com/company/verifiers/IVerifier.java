package com.company.verifiers;

public interface IVerifier<T> {
    public boolean verify(T obj);
}
