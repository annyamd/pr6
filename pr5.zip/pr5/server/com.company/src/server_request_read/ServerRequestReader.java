package server_request_read;

import exceptions.NonexistentRequestException;
import serialize.ObjByteConverter;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.util.Arrays;

public class ServerRequestReader {

    public static CommandERequest readRequest(DatagramSocket datagramSocket) throws NonexistentRequestException {
        byte[] buff = new byte[20000];
        DatagramPacket datagramPacket = new DatagramPacket(buff, buff.length);
        try {
            datagramSocket.receive(datagramPacket);
            System.out.println(datagramPacket.getData()[0] + " " + buff.length);
            CommandERequest commandERequest = ObjByteConverter.deserializeObj(buff);
            commandERequest.setAddressAndPort(datagramPacket.getAddress(), datagramPacket.getPort());
            return commandERequest;
        } catch (IOException e){
            System.out.println("Server: can't read request");
            e.printStackTrace();
        } catch (ClassNotFoundException e){
            e.printStackTrace();
            throw new NonexistentRequestException(datagramPacket.getAddress(), datagramPacket.getPort());
        } finally {
            Arrays.fill(buff,(byte) 0);
        }
        return null;
    }

}