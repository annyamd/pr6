package commands;

import command_control.gen.ParamBox;
import command_control.gen.Param;
import db.MusicBandHashSet;
import commands.templer.Command;
import model.MusicBand;

public class AddCommand extends Command {

    private MusicBand elem;

    public AddCommand(MusicBandHashSet receiver, ParamBox params){
        super(receiver, params);
        Param p;
        if (params.size() == 1){//.....крч должно быть поле с названием параметра и проверка при распаковке
            this.elem = (MusicBand) (params.toUnpack().get().getVal());
        }
    }

    @Override
    public ParamBox execute() {
        receiver.getData().add(elem);
        return null;
    }

}