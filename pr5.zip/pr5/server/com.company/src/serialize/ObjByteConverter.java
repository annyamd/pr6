package serialize;

import java.io.*;

public class ObjByteConverter {
    public static byte[] serializeObj(Object obj) throws IOException {
        System.out.println("s: " + obj);
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        ObjectOutputStream serializeStream = new ObjectOutputStream(byteArrayOutputStream);
        serializeStream.writeObject(obj);
        byte[] bytes = byteArrayOutputStream.toByteArray();
        serializeStream.close();
        System.out.println("s2: " + bytes[0]);
        return bytes;
    }

    public static <T extends Serializable> T deserializeObj(byte[] buff) throws IOException, ClassNotFoundException{
        System.out.println("des: " + buff[0]);
        ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(buff);
        ObjectInputStream deserializeStream = new ObjectInputStream(byteArrayInputStream);
        T obj = (T) deserializeStream.readObject();
        deserializeStream.close();
        return obj;
    }
}
