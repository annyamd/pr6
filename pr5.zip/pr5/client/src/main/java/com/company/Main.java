package com.company;

import com.company.io.MBTerminal;

/**
 * @author Anna Mikhailova
 */

public class Main {

    public static void main(String[] args) {
        new MBTerminal().start();
    }

}
