package commands;

import commands.templer.Command;
import command_control.gen.ParamBox;
import db.MusicBandHashSet;
import model.MusicBand;

public class RemoveGreaterCommand extends Command {
    private MusicBand elem;

    public RemoveGreaterCommand(MusicBandHashSet receiver, ParamBox params){
        super(receiver, params);
        if (params.size() == 1){
            elem = (MusicBand) params.toUnpack().get().getVal();
        }
    }

    @Override
    public ParamBox execute() {
        receiver.getData().removeIf(mb -> mb.compareTo(elem) > 0);
        return null;
    }
}
