package com.company.io;

import exceptions.IncorrectInputException;
import com.company.exceptions.InflateException;
import com.company.io.inflaters.*;
import server_request_read.CommandERequest;
import com.company.client_connection.ServerCommunicator;
import command_control.gen.*;
import exceptions.*;
import model.MusicGenre;
import server_connection_response.Response;

import java.io.File;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.PortUnreachableException;

public class MBTerminal {
    public static final int PORT = 7777;

    private IOHandler handler;
    private ServerCommunicator serverCommunicator;
    private boolean toContinue = true;
    private ExceptionListener exceptionListener = e -> toContinue = false;
    private boolean isCommandCompleted;
    private Writer resultWriter;

    public MBTerminal() {
        init();
    }

    public void start() {

        while (toContinue) {
            handler.getWriter().writeln("Write next command: ");

            try {
                CommandType cmd = handler.getReader().readCommand();
                if (cmd.equals(CommandType.EXIT)) System.exit(0);
                isCommandCompleted = false;
                ParamType[] params = cmd.getParamTypes();
                ParamBox paramBox = new ParamBox(params.length);
                Object val;

                int primitivesCount = cmd.getPrimitivesCount();
                String[] primitives = handler.getReader().readPrimitiveParams();
                if (primitives.length != primitivesCount) throw new IncorrectInputException();

                //reading primitive params
                for (int i = 0; i < primitives.length; i++) {
                    val = handler.getReader().objToPrimitive(params[i], primitives[i]);
                    if (val == null) throw new IncorrectInputException();
                    paramBox.add(new Param(params[i], val));
                }

                //reading object params
                for (int i = primitivesCount; i < paramBox.size(); i++) {
                    ParamType type = params[i];
                    val = handler.readObject(type);
                    paramBox.add(new Param(type, val));
                }

                //call to server - serialize command, its params, send and wait to get result
                System.out.println(cmd);
                Response<ParamBox> serverResponse = serverCommunicator.sendRequest(new CommandERequest(cmd, paramBox));

                ParamBox res = serverResponse.geResponseObj();

                isCommandCompleted = true;
                resultWriter.writeParamBox("Result", res);
                handler.getWriter().writeln("Command completed execution.");
            } catch (Exception e) {
                getExceptionListener().onExceptionGet(e);
            }
        }
    }

    private void init() {

        try {
            serverCommunicator = new ServerCommunicator();
            serverCommunicator.setTarget(new InetSocketAddress("localhost", PORT));
        } catch (IOException e) {
            exit();
        }

        this.resultWriter = new Writer();

        this.exceptionListener = e -> {
            if (e instanceof NoSuchCommandException) {
                handler.getWriter().writeln(e.toString());
            } else if (e instanceof IncorrectInputException | e instanceof InflateException) {
                handler.getWriter().writeln(e.toString() + " Try again.");
            } else if (e instanceof PortUnreachableException){
                handler.getWriter().writeln("Can't connect with server. Try again.");
            } else if (e instanceof ServerClientException || e instanceof IOException){
                System.out.println("problem client|server");
                e.printStackTrace();
                exit();
            }
        };

        handler = new IOHandler(getExceptionListener()) {
            @Override
            public Inflater getInflater(ParamType type) {
                switch (type) {
                    case MUSIC_BOX:
                        return new MusicBandInflater();
                    case COORDINATES:
                        return new CoordinatesInflater();
                    case STUDIO:
                        return new StudioInflater();
                    case MUSIC_GENRE:
                        return new EnumInflater<>("music genre", MusicGenre.class);
                }
                return null;
            }
        };
    }

    public void exit() {
        toContinue = false;
        handler.getReader().close();
        try {
            serverCommunicator.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void executeScript(String fileName) {

        try {
            CommandReader reader = new CommandReader(new File(fileName));

            Writer writer = new Writer() {
                @Override
                public void write(String str) {
                }

                @Override
                public void writeln(String str) {
                }
            };

            handler.setReader(reader);
            handler.setWriter(writer);

            ExceptionListener mainEL = getExceptionListener();
            exceptionListener = e -> toContinue = false;

            handler.setExceptionListener(getExceptionListener());

            start();

            exceptionListener = mainEL;
            handler.setExceptionListener(mainEL);
            handler.setReader(new CommandReader());
            handler.setWriter(new Writer());

            if (toContinue || isCommandCompleted) {
                handler.getWriter().writeln("Script completed execution successfully.");
            } else handler.getWriter().writeln("Script execution error.");

            toContinue = true;

        } catch (IOException e) {
            handler.getWriter().writeln("Reading file error.");
        }
    }

    public ExceptionListener getExceptionListener() {
        return exceptionListener;
    }

    interface ExceptionListener {
        void onExceptionGet(Exception e);
    }
}
