module client {
    requires server;

}