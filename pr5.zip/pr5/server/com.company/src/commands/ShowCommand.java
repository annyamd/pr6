package commands;

import command_control.gen.ParamBox;
import commands.templer.Command;
import command_control.gen.Param;
import command_control.gen.ParamType;
import db.MusicBandHashSet;

public class ShowCommand extends Command {

    public ShowCommand(MusicBandHashSet receiver) {
        super(receiver);
    }

    @Override
    public ParamBox execute() {
//
//        String strPresentation = "";
//
//        for (Object elem : receiver.getDataAsSortedList()){
//            strPresentation += elem.toString() + "\n";
//        }

        return new ParamBox(1).add(new Param(ParamType.LIST, "List", receiver.getDataAsSortedList())).toPack();
    }
}
