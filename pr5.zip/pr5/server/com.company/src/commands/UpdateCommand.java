package commands;

import command_control.gen.ParamBox;
import db.MusicBandHashSet;
import commands.templer.Command;
import model.MusicBand;

public class UpdateCommand extends Command {

    private long id;
    private MusicBand elem;

    public UpdateCommand(MusicBandHashSet receiver, ParamBox paramBox){
        super(receiver, paramBox);

        if (paramBox.size() == 2) {
            this.id = (long) paramBox.toUnpack().get().getVal();
            this.elem = (MusicBand) paramBox.get().getVal();
        }
    }

    @Override
    public ParamBox execute() {
        if (receiver.removeById(id)){
            receiver.getData().add(elem);
        }
        return null;
    }
}
