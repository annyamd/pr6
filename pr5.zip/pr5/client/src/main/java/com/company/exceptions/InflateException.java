package com.company.exceptions;

public class InflateException extends Exception{
    @Override
    public String toString() {
        return "Incorrect input.";
    }
}
