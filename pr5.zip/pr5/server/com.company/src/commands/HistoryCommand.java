package commands;

import commands.templer.Command;
import command_control.CommandManager;
import command_control.gen.Param;
import command_control.gen.ParamBox;
import command_control.gen.ParamType;

public class HistoryCommand extends Command {

    private CommandManager commandManager;

    public HistoryCommand(CommandManager receiver){
        this.commandManager = receiver;
    }

    @Override
    public ParamBox execute() {
        return new ParamBox(1).add(new Param(ParamType.LIST, commandManager.getCommandList())).toPack();
    }
}
