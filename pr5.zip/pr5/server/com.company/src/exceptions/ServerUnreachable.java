package exceptions;

public class ServerUnreachable extends ServerClientException{
}
