package exceptions;

public class IncorrectInputException extends Exception {
    @Override
    public String toString() {
        return "Incorrect input.";
    }
}
