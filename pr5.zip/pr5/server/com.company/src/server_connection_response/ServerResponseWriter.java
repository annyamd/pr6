package server_connection_response;

import serialize.ObjByteConverter;

import java.io.IOException;
import java.io.Serializable;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
public class ServerResponseWriter {

    public static <T extends Serializable> void sendResponse(DatagramSocket socket, InetAddress address, int port, Response<T> response){
        try {
            System.out.println(response);
            byte[] bytes = ObjByteConverter.serializeObj(response);
            socket.send(new DatagramPacket(bytes, bytes.length, address, port));
        } catch (IOException e){
            System.out.println("Server: can't send a response.");
        }
    }

}
