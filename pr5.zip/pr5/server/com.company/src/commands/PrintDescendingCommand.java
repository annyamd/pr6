package commands;

import commands.templer.Command;
import command_control.gen.Param;
import command_control.gen.ParamBox;
import command_control.gen.ParamType;
import db.MusicBandHashSet;
import model.MusicBand;

import java.util.ArrayList;
import java.util.Collections;

public class PrintDescendingCommand extends Command {

    public PrintDescendingCommand(MusicBandHashSet musicBandHashSet){
        super(musicBandHashSet);
    }

    @Override
    public ParamBox execute() {
        ArrayList<MusicBand> musicBand = new ArrayList<>(receiver.getData()); //Sorted Set
        Collections.sort(musicBand);
        Collections.reverse(musicBand);
        return new ParamBox(1).add(new Param(ParamType.LIST, Param.NO_NAME_FIELD, musicBand)).toPack();
    }
}
