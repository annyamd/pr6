package server;

import exceptions.NonexistentRequestException;
import serialize.Convertions;
import server_connection_response.Response;
import server_request_read.CommandERequest;
import command_control.CommandManager;
import command_control.gen.CommandType;
import command_control.gen.ParamBox;
import db.MusicBandHashSet;
import model.MusicBand;
import server_request_read.ServerRequestReader;
import server_connection_response.ServerResponseWriter;
import server_connection_set.ClientConnection;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class CommandsServer {
    static final String inputFileExtension = "csv";
    public static final int PORT = 7777;
    public static DataFile<MusicBand> dataFile;
    public static MusicBandHashSet musicBands;

    public static void main(String[] args) {

        boolean running = true;

        String fileName = args[0];
        if (fileName == null || !fileName.endsWith(inputFileExtension)) {
            System.out.print("Server: incorrect format of file.");
        } else {
            try {
                dataFile = new DataFile<>(fileName);
                musicBands = new MusicBandHashSet(dataFile.readDataList());
                System.out.println(musicBands.toString());
                CommandManager commandManager = new CommandManager(musicBands);
                ClientConnection connection = new ClientConnection();
                connection.setOnConnection(PORT);

                while (running) {
                    try {
                        CommandERequest request = ServerRequestReader.readRequest(connection.getDatagramSocket());
                        System.out.println("read: " + request.getCommandType().toString());
                        CommandType commandType = request.getCommandType();
                        ParamBox params = request.getParams();
                        ParamBox res = commandManager.execute(commandType, params);
                        ServerResponseWriter.sendResponse(connection.getDatagramSocket(), request.getAddress(), request.getPort(),
                                new Response<>(res, true, "Successful execution"));

                        connection.stop();
                        checkTerminal();
                        System.out.println("uuuuutttttttu");
                        connection.revive();
                        System.out.println("12uuuuutttttttu");

                    } catch (NonexistentRequestException e) {
                        ServerResponseWriter.sendResponse(connection.getDatagramSocket(), e.getClientAddress(), e.getClientPort(),
                                new Response<>(null, false, "Server can't read request"));
                    }
                }

            } catch (IOException e) {
                e.printStackTrace();
                System.out.println("uuuuuu");
            } finally {
                save();
            }
        }
    }

    public static void checkTerminal() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Save current state? Yes/No");

        if (scanner.hasNext()) {
            String ans = Convertions.convertNullableStrToNull(scanner.next());
            if (ans != null && ans.equals("Yes")) {
                System.out.println("Saved.");
                save();
            }
        }
        System.out.println("Did not save.");
        scanner.close();
    }

    public static void save() {
        dataFile.save(new ArrayList<>(musicBands.getData()));
    }

}
